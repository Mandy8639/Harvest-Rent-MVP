# Harvest-Rent-MVP (Ready-to-run)

This is a runnable MVP scaffold for a harvester rental marketplace (backend + Expo mobile demo).

## What's included
- backend/: Node.js + Express backend with simple routes (auth OTP stub, equipment CRUD, bookings)
- docker-compose.yml to run Postgres + backend locally
- mobile/: Expo-based React Native demo app (mocked data). Easy to wire to backend.

## How to run (recommended: Linux / WSL / Mac)

1. Start Docker containers (Postgres + backend):
   - `docker-compose up --build`
   This will build and run the backend on port 4000 and Postgres on 5432.

2. Run migrations to create tables:
   - Exec into the db container and run the SQL, or use psql:
     - `docker exec -it $(docker ps --filter "ancestor=postgres:15" -q) psql -U postgres -d harvestrent -f /usr/src/app/backend/src/models/migrations.sql`
   Simpler: copy `backend/src/models/migrations.sql` and run it from your local psql client.

3. Start the Expo mobile app:
   - `cd mobile`
   - `npm install` (or `yarn`)
   - `expo start`
   Open in Expo Go (Android) to see the demo app.

## Notes
- OTP is stubbed and printed in backend logs. Replace with MSG91/Twilio for production.
- Payments are mocked. Integrate Razorpay / Paytm for real transactions.
- Replace dev tokens with JWT and secure secrets before going live.

## Next steps I can help with
- Wire real OTP provider + Redis.
- Integrate Razorpay sandbox for payments.
- Seed DB with sample owners and bookings + Postman collection.
- Add JWT auth, role-based access, and admin UI.
