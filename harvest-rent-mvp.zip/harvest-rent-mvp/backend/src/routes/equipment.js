const express = require('express');
const router = express.Router();
const db = require('../db');

// POST /api/equipment - create listing (basic)
router.post('/', async (req, res) => {
  try {
    const { owner_id, title, type, model, capacity, daily_price, lat, lng, images } = req.body;
    const q = `INSERT INTO equipment(owner_id, title, type, model, capacity, daily_price, lat, lng, images)
               VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`;
    const values = [owner_id, title, type, model, capacity, daily_price, lat, lng, images || []];
    const r = await db.query(q, values);
    res.send({ ok: true, equipment: r.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: 'server_error' });
  }
});

// GET /api/equipment/search?lat=&lng=&radius_km=&type=
router.get('/search', async (req, res) => {
  try {
    const { lat, lng, radius_km = 50, type } = req.query;
    if (!lat || !lng) return res.status(400).send({ error: 'lat,lng required' });
    const latNum = parseFloat(lat), lngNum = parseFloat(lng);
    const r = await db.query(
      `SELECT *, ( (lat - $1)*(lat - $1) + (lng - $2)*(lng - $2) ) as dist_approx
       FROM equipment
       WHERE ($3::text IS NULL OR type = $3)
       ORDER BY dist_approx ASC LIMIT 50`, [latNum, lngNum, type || null]
    );
    res.send({ ok: true, results: r.rows });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: 'server_error' });
  }
});

module.exports = router;
