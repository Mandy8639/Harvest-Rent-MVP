const express = require('express');
const router = express.Router();
const { sendOtp } = require('../services/otpService');
const db = require('../db');

// POST /api/auth/request-otp
router.post('/request-otp', async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.status(400).send({ error: 'phone required' });
    const otp = await sendOtp(phone);
    await db.query('INSERT INTO otps(phone, otp) VALUES($1,$2) ON CONFLICT (phone) DO UPDATE SET otp=$2, created_at=NOW()', [phone, otp]);
    return res.send({ ok: true, message: 'otp_sent' });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: 'server_error' });
  }
});

// POST /api/auth/verify-otp
router.post('/verify-otp', async (req, res) => {
  try {
    const { phone, otp } = req.body;
    if (!phone || !otp) return res.status(400).send({ error: 'phone and otp required' });
    const r = await db.query('SELECT otp, created_at FROM otps WHERE phone=$1', [phone]);
    if (r.rowCount === 0) return res.status(400).send({ error: 'no_otp' });
    const row = r.rows[0];
    if (String(row.otp) !== String(otp)) return res.status(400).send({ error: 'invalid_otp' });

    let user = await db.query('SELECT id, phone FROM users WHERE phone=$1', [phone]);
    if (!user.rowCount) {
      const ins = await db.query('INSERT INTO users (phone) VALUES($1) RETURNING id, phone', [phone]);
      user = ins;
    }
    const token = `devtoken-${user.rows[0].id}-${Date.now()}`;
    res.send({ ok: true, token, user: user.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: 'server_error' });
  }
});

module.exports = router;
