const express = require('express');
const router = express.Router();
const db = require('../db');

// POST /api/bookings
router.post('/', async (req, res) => {
  try {
    const { equipment_id, renter_id, start_date, end_date, price } = req.body;
    if (!equipment_id || !renter_id || !start_date || !end_date) return res.status(400).send({ error: 'missing' });
    const r = await db.query(
      `INSERT INTO bookings(equipment_id, renter_id, start_date, end_date, price, status)
       VALUES($1,$2,$3,$4,$5,'requested') RETURNING *`,
      [equipment_id, renter_id, start_date, end_date, price || 0]
    );
    res.send({ ok: true, booking: r.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: 'server_error' });
  }
});

// POST /api/bookings/:id/confirm (owner confirms)
router.post('/:id/confirm', async (req, res) => {
  try {
    const { id } = req.params;
    await db.query('UPDATE bookings SET status=$1 WHERE id=$2', ['confirmed', id]);
    res.send({ ok: true, id });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: 'server_error' });
  }
});

module.exports = router;
