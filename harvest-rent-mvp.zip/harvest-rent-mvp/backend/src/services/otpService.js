async function sendOtp(phone) {
  const otp = Math.floor(100000 + Math.random()*900000);
  console.log('DEBUG OTP for', phone, otp);
  return otp;
}
module.exports = { sendOtp };
