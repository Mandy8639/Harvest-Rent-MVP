-- basic tables for MVP
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  phone VARCHAR(20) UNIQUE NOT NULL,
  name TEXT,
  role VARCHAR(20) DEFAULT 'renter',
  kyc_status VARCHAR(20) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS otps (
  phone VARCHAR(20) PRIMARY KEY,
  otp VARCHAR(10),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS equipment (
  id SERIAL PRIMARY KEY,
  owner_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  title TEXT,
  type VARCHAR(50),
  model TEXT,
  capacity TEXT,
  daily_price NUMERIC(10,2),
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  images TEXT[],
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bookings (
  id SERIAL PRIMARY KEY,
  equipment_id INTEGER REFERENCES equipment(id),
  renter_id INTEGER REFERENCES users(id),
  start_date TIMESTAMP,
  end_date TIMESTAMP,
  price NUMERIC(12,2),
  status VARCHAR(30) DEFAULT 'requested',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  booking_id INTEGER REFERENCES bookings(id),
  amount NUMERIC(12,2),
  status VARCHAR(30) DEFAULT 'pending',
  gateway_txn_id TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reviews (
  id SERIAL PRIMARY KEY,
  booking_id INTEGER REFERENCES bookings(id),
  reviewer_id INTEGER REFERENCES users(id),
  rating SMALLINT,
  comment TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
