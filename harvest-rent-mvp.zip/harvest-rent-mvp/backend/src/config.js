module.exports = {
  PORT: process.env.PORT || 4000,
  DATABASE_URL: process.env.DATABASE_URL || 'postgres://postgres:postgres@db:5432/harvestrent',
  JWT_SECRET: process.env.JWT_SECRET || 'devsecret',
};
