// index.js - simple Express server with core routes
const express = require('express');
const bodyParser = require('body-parser');
const config = require('./config');
const db = require('./db');

const authRoutes = require('./routes/auth');
const equipmentRoutes = require('./routes/equipment');
const bookingRoutes = require('./routes/bookings');

const app = express();
app.use(bodyParser.json());

app.use('/api/auth', authRoutes);
app.use('/api/equipment', equipmentRoutes);
app.use('/api/bookings', bookingRoutes);

app.get('/', (req, res) => res.send({ ok: true, service: 'harvest-rent-mvp' }));

const port = config.PORT || 4000;
app.listen(port, () => console.log(`Server running on port ${port}`));
