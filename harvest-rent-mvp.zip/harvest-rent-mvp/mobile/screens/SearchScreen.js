import React from 'react';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';

const MOCK = [
  { id: 1, title: 'Combine Harvester - John', daily_price: 25000, lat: 26.9, lng: 80.9 },
  { id: 2, title: 'Combine Harvester - Sharma Farms', daily_price: 22000, lat: 26.8, lng: 81.0 },
];

export default function SearchScreen({ navigation }) {
  return (
    <View style={{flex:1, padding:16}}>
      <Text style={{fontSize:18, fontWeight:'bold', marginBottom:12}}>Nearby Harvesters</Text>
      <FlatList
        data={MOCK}
        keyExtractor={i=>String(i.id)}
        renderItem={({item}) => (
          <TouchableOpacity onPress={()=>navigation.navigate('Equipment', { item })} style={{padding:12, borderBottomWidth:1}}>
            <Text style={{fontSize:16}}>{item.title}</Text>
            <Text>₹ {item.daily_price} / day</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
