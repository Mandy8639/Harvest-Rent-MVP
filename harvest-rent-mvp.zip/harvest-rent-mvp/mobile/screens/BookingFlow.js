import React from 'react';
import { View, Text, Button } from 'react-native';

export default function BookingFlow({ route, navigation }) {
  const { item } = route.params;
  return (
    <View style={{flex:1, padding:16}}>
      <Text style={{fontSize:18}}>Booking: {item.title}</Text>
      <Text>Start date: today (demo)</Text>
      <Text>End date: tomorrow (demo)</Text>
      <Text>Estimated price: ₹{item.daily_price}</Text>
      <Button title="Confirm & Pay (mock)" onPress={()=>{
        alert('Booking requested. In production integrate Razorpay/UPI flow.');
        navigation.popToTop();
      }} />
    </View>
  );
}
