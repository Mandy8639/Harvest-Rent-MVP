import React from 'react';
import { View, Text, Button } from 'react-native';

export default function EquipmentDetail({ route, navigation }) {
  const { item } = route.params;
  return (
    <View style={{flex:1, padding:16}}>
      <Text style={{fontSize:20, fontWeight:'bold'}}>{item.title}</Text>
      <Text>Price: ₹{item.daily_price} / day</Text>
      <Text style={{marginTop:12}}>Details: Combine harvester, good condition. Operator optional.</Text>
      <Button title="Book now" onPress={()=>navigation.navigate('Booking', { item })}/>
    </View>
  );
}
